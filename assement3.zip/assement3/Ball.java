/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assement3;

/**
 *
 * @author WAY
 */
public abstract class Ball implements Tossable{
    
    String brandName;

    public Ball(String brandName) {
        this.brandName = brandName;
    }
    
    public String getBrandName() {
        return brandName;
    }
    
    @Override
    public void toss() {}

   public abstract void bounce();
}
